package com.example.investindobem;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText PMT;
    private EditText FV;
    private EditText i0;
    private EditText n0;

    private AlertDialog.Builder dialog;
    private Button botaoCalcular;

    private String PMT2;
    private String FV2;
    private String i2;
    private String n2;

    private Double pmt;
    private Double fv;
    private Double i;
    private Integer n;

    private Double total;
    private Double imais1ElevadoAn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PMT = findViewById(R.id.etValorMensal);
        FV = findViewById(R.id.etValorFinal);
        i0 = findViewById(R.id.etTaxaDeJuros);
        n0 = findViewById(R.id.etMeses);
        botaoCalcular = findViewById(R.id.btCalcular);

        botaoCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            PMT2 = PMT.getText().toString();
            FV2 = FV.getText().toString();
            i2 = i0.getText().toString();
            n2 = n0.getText().toString();

            //quando quer saber o valor total

            if (FV2.equals("")){
                if (PMT2.equals("") || i2.equals("")||n2.equals("")){

                    //criar o dialog
                    dialog = new AlertDialog.Builder(MainActivity.this);

                    //configurar dialog
                    dialog.setTitle("Ops!");

                    //configurar mensagem
                    dialog.setMessage("você deixou mais de um valor em branco.");

                    dialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(MainActivity.this, "Tela principal", Toast.LENGTH_SHORT).show();

                        }
                    });
                    dialog.create();
                    dialog.show();
                }else {
                    pmt = Double.parseDouble(PMT2);
                    i = Double.parseDouble(i2);
                    i = i / 100;
                    n = Integer.parseInt(n2);

                    total = pmt * (1 + i) * ((Math.pow(1 + i, n) - 1) / i);

                    //criar o dialog
                    dialog = new AlertDialog.Builder(MainActivity.this);

                    //configurar dialog
                    dialog.setTitle("Resultado");

                    //configurar mensagem
                    dialog.setMessage("Valor obtido ao final:" + total);

                    dialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(MainActivity.this, "Tela principal", Toast.LENGTH_SHORT).show();

                        }
                    });
                    dialog.create();
                    dialog.show();




                    //quando quer saber a parcela


                }
            }else if (PMT2.equals("")){
                    if (FV2.equals("") || i2.equals("") || n2.equals("")){

                        //criar o dialog
                        dialog = new AlertDialog.Builder(MainActivity.this);

                        //configurar dialog
                        dialog.setTitle("Ops!");

                        //configurar mensagem
                        dialog.setMessage("você deixou mais de um valor em branco.");

                        dialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Tela principal", Toast.LENGTH_SHORT).show();

                            }
                        });
                        dialog.create();
                        dialog.show();

                    }else{

                        //calculo das parcelas
                        fv = Double.parseDouble(FV2);
                        i = Double.parseDouble(i2);
                        i = i / 100;
                        n = Integer.parseInt(n2);

                        total = fv/((Math.pow(1 + i, n) - 1) / i);



                    //criar o dialog
                        dialog = new AlertDialog.Builder(MainActivity.this);

                        //configurar dialog
                        dialog.setTitle("Resultado");

                        //configurar mensagem
                        dialog.setMessage("Valor a ser depositado mensalmente:" + total);

                        dialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Tela principal", Toast.LENGTH_SHORT).show();

                            }
                        });
                        dialog.create();
                        dialog.show();

                    }

                }else if(i2.equals("")) {

                    if (FV2.equals("") || PMT2.equals("") || n2.equals("")){

                        //criar o dialog
                        dialog = new AlertDialog.Builder(MainActivity.this);

                        //configurar dialog
                        dialog.setTitle("Ops!");

                        //configurar mensagem
                        dialog.setMessage("você deixou mais de um valor em branco.");

                        dialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Tela principal", Toast.LENGTH_SHORT).show();

                            }
                        });
                        dialog.create();
                        dialog.show();



                }else{
                        //codigo para saber a taxa

                        fv = Double.parseDouble(FV2);
                        pmt= Double.parseDouble(PMT2);
                        n = Integer.parseInt(n2);

                        // total = fv/((Math.pow(1 + i, n) - 1) / i);

                        //criar o dialog
                        dialog = new AlertDialog.Builder(MainActivity.this);

                        //configurar dialog
                        dialog.setTitle("Resultado");

                        //configurar mensagem
                        dialog.setMessage("Função não implementada" );

                        dialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this, "Tela principal", Toast.LENGTH_SHORT).show();

                            }
                        });
                        dialog.create();
                        dialog.show();

                    }

            }
            }


            // formula geral FV = PMT*(1+i)*((((1+i)^n)-1)/i)
            // FV: valor futuro
            // PMT: valor dos depósitos
            // n: número de depósitos
            // i: taxa unitária de juros


        });
    }
}